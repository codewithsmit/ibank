from django.apps import AppConfig


class BranchConfig(AppConfig):
    name = 'branch'
