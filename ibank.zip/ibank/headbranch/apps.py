from django.apps import AppConfig


class HeadbranchConfig(AppConfig):
    name = 'headbranch'
